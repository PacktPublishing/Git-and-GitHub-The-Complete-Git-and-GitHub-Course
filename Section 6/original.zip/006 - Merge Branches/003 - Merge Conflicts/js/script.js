const c = 50;

const b = () => {
	console.log('Hi there');
};
