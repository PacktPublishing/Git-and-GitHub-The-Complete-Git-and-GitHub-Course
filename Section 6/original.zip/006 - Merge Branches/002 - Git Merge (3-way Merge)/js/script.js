const a = 100;
const b = () => {};
